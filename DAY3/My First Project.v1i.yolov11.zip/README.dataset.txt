# My First Project > 2025-09-19 2:38pm
https://universe.roboflow.com/computervisioncourse3/my-first-project-bovdt

Provided by a Roboflow user
License: CC BY 4.0

